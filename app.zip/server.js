import express from "express";

const app = express();
app.use(express.json());

// let practices = [
//   {
//     id : 1, 
//     admins: [
//     {"uuid": 123},
//     {"uuid": 456} 
//     ],
//     code: "ABC123",
//     courtsNum: 4,
//     courts: [
//       {uuid : 1},
//       {uuid: 2}
//     ],
//     parties: [
//       {partyID: 4},
//       {partyID: 7}
//     ],
//     queueChips
//   }
// ]

let players_1 = [
  { uuid: 1, username: "john", password: "password123", skill: "beginner" },
  { uuid: 2, username: "david", password: "password123", skill: "intermediate" },
  { uuid: 3, username: "sarah", password: "password123", skill: "advanced" },
];


app.get("/api/players", (req, res) => {
  res.json(players);
});

app.listen(3001, () => console.log("Server running on http://localhost:3001"));
